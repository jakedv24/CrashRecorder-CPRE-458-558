package com.veatch_tutic.crashrecorder.view_models

import androidx.lifecycle.ViewModel

open class ViewFinderViewModel : ViewModel() {
    fun startRecording() {

    }
}