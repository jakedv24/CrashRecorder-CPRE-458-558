package com.veatch_tutic.crashrecorder.fragments

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.veatch_tutic.crashrecorder.view_models.ViewFinderViewModel

class ViewFinderFragment : Fragment() {
    private lateinit var viewModel: ViewFinderViewModel

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = DataBindingUtil.inflate(
            inflater,
            R.layout.game_fragment,
            container,
            false
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


    }
}